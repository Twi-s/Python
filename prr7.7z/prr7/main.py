# print("введите строку")
# str1 = input()
# n = 0
# print(str1.replace("а","ф"))
# if str1.__contains__("а"):
#     for n in range(str1.__len__()):
#         if str1[n]== "a":
#             n = n + 1
# print(n)

from array import
my_array1 = array(1,1,3,3,5,9,7,8,9,10,11,12,5,14,15)
my_array2 = array()
while 