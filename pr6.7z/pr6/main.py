#5
import math
import random

# number = int (input(f"number"))
# factorial = number
#
# for i in range(number):
#     factorial = number *  i
# print(factorial)

#3
# import math
# a = int (input ("число введи"))
# b = int (input ("число введи"))
# f = a + b
# for c in f:
#     print(c)
# else:
#     print(f)

#8
# b = random.randint(0,100)
# for i in range(0,10):
#     a = int(input())
#     if  a == b:
#         print("Победа")
#     elif a < b:
#         print("меньше")
#     elif a > b:
#         print("Больше")
# print("Не угодал")

#1
a = int(input())
b = int(input())
c = int(input())
print("1 = *")
d = input()
if d == ("1"):
    f = a * b * c
    print(f)













