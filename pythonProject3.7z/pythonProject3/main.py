import telebot
bot = telebot.TeleBot('6050641712:AAHIis-picZBU5iEPQTXdz0tzP_7Qs0j8ZE')
@bot.message_handler(commands=["start"])
def start(m, res=False):
    bot.send_message(m.chat.id, 'хватит играть в геншин)')

@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text == 'ку':
        bot.send_message(message.chat.id, 'ку')
    if message.text == 'Я дед':
        bot.send_message(message.chat.id, 'Хватит в геншине сидеть, пошли в сатисфэктори ')
    if message.text == 'я голубой':
        bot.send_message(message.chat.id, 'иди в радугу тогда играй ')
    if message.text == 'Калькулятор':
        if message.text == 'Сложение':
            bot.send_message(message.chat.id, 'Напишите числа')
            bot.register_next_step_handler(message, AddElement)

def AddElement(message):
    global item
    global a
    global b
    item=message.text
    a = str(item).split(' ')
    b=0
    for s in a:
        b+=int(s)
    bot.send_message(message.from_user.id, b)

bot.polling(none_stop=True, interval=0)

