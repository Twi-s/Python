# message = "Привет никита"
# print("Привет никита")
#
# name = 'Дота 2'
# print(name)
#
# text = ("Сегодня без доты, так что иди Томас Шелби")
# print(text)
#
# text = '''просто слова
# возраст никиты 17
# настоящий возраст никиты 5'''
#
# print(text)
# import math
#
# a = float (input("Число"))
# z1 = (math.sin(2*a)+math.sin(5*a)-math.sin(3*a)) / (math.cos(a)+(1)-2*math.sin(2*a)**2)
# z2 = 2*math.sin(a)
# print(z1)
# print(z2)
# print(text)
import math



a = float (input("Число"))
z1 = math.cos(a)+math.cos(2*a)+math.cos(6*a)+math.cos(7*a)
z2 = 4*math.cos(a/2)*math.cos(5/2*a)*math.cos(4*a)
print(z1)
print(z2)














