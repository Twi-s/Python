def print_person(name, age=18):
    print(f"name: {name} age: {age}")


print_person(input())