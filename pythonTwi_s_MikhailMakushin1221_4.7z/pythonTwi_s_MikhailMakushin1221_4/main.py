# number = 10
# while number < 1000:
#     print(f"number = {number}")
#     number += 1
# else:
#     print(f"number = {number}. Работа цикла закончена")
#     print("Работа завершена")
# number += 1

# a = 1
# b = 2
# while a < 10:
#     while b < 10:
#         print (a * b, end="\t")
#         b += 1
#     print("\n")
#     b = 1
#     a += 1

# number = 156
# while number < 566:
#     number += 1
#     if number == 3:
#         break
#     print(f"number = {number}")

# import math
# a = -0.5
# b = 2.5
# h = 0.2
# while a < b:
#     i = a * math.sin(math.pi/4) / 1 - 2*a**math.cos(math.pi/4) + 2**a
#     print(i)
#     a = a + h

import math
a = 10
b = 20
h = 1
s = 0
while a < b:
    # s = (math.cos(a*math.pi / 4) / math.factorial(a)) * a**a
    y = math.e**(a*math.cos(math.pi/4))*math.cos(a*math.sin(math.pi/4))
    s = s + (math.cos(a*math.pi / 4) / math.factorial(a)) * a**a
    print(s, y)
    a = a + h




