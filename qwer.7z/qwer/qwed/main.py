# def print_person(name, age=18):
#     print(f"name: {name} age: {age}")
#
#
# print_person(input())
# print_person(input())
import math


# def sum(*numbers):
#     result = 0
#     for n in numbers:
#         result += n
#     print(f"sum = {result}")
#
# sum(15,10,19)
# sum(15,10,19,19554,45845)

# def say_hello(name="Tom"):
#     print(f"Hello, {name}")
#
# say_hello()
# say_hello(input())

# def say_hello(name):
#     print(f"Hello, {name}")
#
# say_hello(input())
# say_hello("Ivan")
# say_hello("Sam")

# def add(*numbers):
#     print(sum(numbers))
#
# add(5,5,2)
#
#
# def addd(*numbers):
#     sum=1
#     for i in numbers:
#         sum*=i
#     print(sum)
#
# addd(5,5,2)
#
# def addd(*numbers):
#     sum=1
#     for i in numbers:
#         sum/=i
#     print(sum)
#
# addd(5,5,2)
#
# def addd(*numbers):
#     sum=1
#     for i in numbers:
#         sum-=i
#     print(sum)
#
# addd(5,5,2)


# def ad1(a):
#     print(math.factorial(a))
#
# ad1(int(input()))

