# номер 1
# print("введи число")
# print("Выберите вариант перевода числа")
# print("1 в двоичную систему")
# print("2 в восьмеричную систему")
# print("3 в шестнадцатеричную систему")
# a = int(input())
# if a == 1:
#     b = int(input())
#     print(bin(b))
# elif a == 2:
#     c = int(input())
#     print(oct(c))
# elif a == 3:
#     g = int(input())
#     print(hex(g))

# номер 4
# a = [1,5,9,7,6,3,1,8,4,2,5,6,3,5,4,5,6,3,5,56,2,5,4,46,584,684,684,65874,68]
# print(a[0])
# print(a[-1])

# def sum_range(start_end):
#     a = [5,5,5,6,74,84,54,4,5,45,4,4,54,84,64]
#     print(sum(a))
#
# sum_range(1)
